#!/usr/bin/env python3
"""Mochi Vault — Browser Data Manager & Web Dashboard (single-file edition).

Commands:
  build                 Generate the dashboard from ~/results/*.json and open it
  clear "keyword"       Remove matching history entries, then rebuild
  show [category]       Print recovered data in the terminal
  merge src dest        Append one file to the end of another (utility)
"""

import argparse
import html
import json
import os
import subprocess
import sys
import webbrowser

PROJECT_DIR = os.path.dirname(os.path.realpath(__file__))
RESULTS_DIR = os.environ.get("VAULT_RESULTS") or os.path.expanduser("~/results")

APP_SERVICE = "MochiVault"
APP_ACCOUNT = "macos-login-password"

DATA_SOURCES = [
    ("password", "password.json"),
    ("history", "history.json"),
    ("bookmark", "bookmark.json"),
    ("cookie", "cookie.json"),
    ("download", "download.json"),
    ("extension", "extension.json"),
]


def load_json(filepath):
    if os.path.exists(filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []


def filter_by_browser(data_list, target_name):
    filtered = []
    for item in data_list:
        b_name = str(item.get("browser") or item.get("Browser") or item.get("source") or "").lower()
        if target_name == "safari" and "safari" in b_name:
            filtered.append(item)
        elif target_name == "brave" and ("brave" in b_name or b_name == "" or "chrome" in b_name or "chromium" in b_name):
            filtered.append(item)
    return filtered


def esc(value):
    return html.escape("" if value is None else str(value), quote=True)


def _sec(*args):
    return subprocess.run(["security"] + list(args), capture_output=True, text=True)


def keychain_get():
    r = _sec("find-generic-password", "-s", APP_SERVICE, "-a", APP_ACCOUNT, "-w")
    return r.stdout.rstrip("\n") if r.returncode == 0 and r.stdout else None


def keychain_set(password):
    _sec("delete-generic-password", "-s", APP_SERVICE, "-a", APP_ACCOUNT)
    r = _sec("add-generic-password", "-U", "-s", APP_SERVICE, "-a", APP_ACCOUNT, "-w", password)
    return r.returncode == 0


def keychain_forget():
    _sec("delete-generic-password", "-s", APP_SERVICE, "-a", APP_ACCOUNT)


def extract_data(binary=None):
    binary = binary or os.path.join(PROJECT_DIR, "cats")
    if not os.path.exists(binary):
        print("[-] Core decryption binary not found:", binary)
        return 1

    cmd = [binary]
    pw = keychain_get()
    if pw:
        print("[+] Keychain unlocked — running full decryption automatically.")
        cmd += ["--keychain-pw", pw]
    else:
        print("[*] No stored keychain password — keychain-protected fields export as metadata only.")

    print("[+] Extracting browser profiles…")
    print("[+]", os.path.basename(binary), "→", RESULTS_DIR)
    result = subprocess.run(cmd, cwd=PROJECT_DIR)
    return result.returncode


def field(item, keys, default="—"):
    for k in keys:
        v = item.get(k)
        if v not in (None, ""):
            return v
    return default


def format_size(num):
    try:
        n = float(num)
    except (TypeError, ValueError):
        return "—"
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024
    return str(num)


def cell(content, strong=False, short=False, cls=""):
    tag = "strong" if strong else "span"
    inner = f"<{tag}{' class=cell-short' if short else ''}>{esc(content)}</{tag}>"
    attrs = f' class="{cls}"' if cls else ""
    return f"<td{attrs}>{inner}</td>"


def text_cell(content, strong=False, short=False):
    tag = "strong" if strong else "span"
    cls = ' class="cell-short"' if short else ""
    return f"<{tag}{cls}>{esc(content)}</{tag}>"


def link_cell(url, label=None):
    return f'<a class="url-link" href="{esc(url)}" target="_blank" rel="noopener">{esc(label if label is not None else url)}</a>'


def copy_cell(value, cell_short=True):
    slim = ' slim' if cell_short else ""
    return f'<div class="copy-wrap{slim}"><code class="copy-val">{esc(value)}</code><button class="copy-btn" data-copy="{esc(value)}">Copy</button></div>'


def time_cell(raw):
    return f'<td class="cell-time"><span class="hist-time" data-raw="{esc(raw)}">{esc(raw)}</span></td>'


def build_passwords(browser_label, items):
    if not items:
        return '<div class="pane-card empty-pane"><div class="empty-art">🔑</div><p class="empty-title">No credentials stored</p><p class="empty-sub">This profile has no saved passwords yet.</p></div>'
    rows = []
    for item in items:
        rows.append(
            "<tr>"
            + cell(field(item, ["url", "origin_url"], "Unknown site"), short=True)
            + cell(field(item, ["username", "username_value"], "—"), strong=True)
            + f"<td>{copy_cell(field(item, ['password', 'password_value'], '—'))}</td></tr>"
        )
    return table_html(
        "password", ["Origin Website", "Username", "Password"],
        rows, '  <colgroup><col class="w-url"><col class="w-user"><col class="w-pwd"></colgroup>\n',
    )


def build_history(browser_label, items):
    if not items:
        return '<div class="pane-card empty-pane"><div class="empty-art">🕘</div><p class="empty-title">No history captured</p><p class="empty-sub">Browsing data will appear here after extraction.</p></div>'
    rows = []
    for item in items:
        title = field(item, ["title"], "Untitled page")
        url = field(item, ["url"], "#")
        rtime = field(item, ["last_visit", "visit_time", "time"], "0")
        count = item.get("visit_count")
        visits = f'<span class="visits" title="{esc(str(count))} visits">×{esc(str(count))}</span>' if count not in (None, "", 0, "0") else ""
        rows.append(
            "<tr>"
            + time_cell(rtime)
            + f'<td class="cell-title">{text_cell(title, strong=True)}{visits}</td>'
            + f"<td>{link_cell(url)}</td>"
            + f'<td class="cell-action"><button class="delete-btn" data-title="{esc(title)}">Delete</button></td></tr>'
        )
    return table_html(
        "history", ["Last Visit", "Page Title", "URL", "Actions"],
        rows, '  <colgroup><col class="w-time"><col class="w-title"><col class="w-url"><col class="w-act"></colgroup>\n',
    )


def build_bookmarks(browser_label, items):
    if not items:
        return '<div class="pane-card empty-pane"><div class="empty-art">⭐</div><p class="empty-title">No bookmarks yet</p><p class="empty-sub">Saved sites will surface here.</p></div>'
    rows = []
    for item in items:
        name = field(item, ["name", "title"], "Untitled")
        url = field(item, ["url"], "#")
        folder = field(item, ["folder"], None)
        folder_html = f'<span class="folder-tag">{esc(folder)}</span>' if folder not in (None, "") else ""
        rows.append(
            "<tr>"
            + f"<td>{text_cell(name, strong=True)}{folder_html}</td>"
            + f"<td>{link_cell(url)}</td></tr>"
        )
    return table_html("bookmark", ["Bookmark", "Target URL"], rows)


def build_cookies(browser_label, items):
    if not items:
        return '<div class="pane-card empty-pane"><div class="empty-art">🍪</div><p class="empty-title">No cookies found</p><p class="empty-sub">Cookie records for this profile are empty.</p></div>'
    rows = []
    for item in items:
        host = field(item, ["host", "domain"], "—")
        name = field(item, ["name"], "—")
        value = field(item, ["value", "cookie"], "—")
        flags = []
        if item.get("is_http_only") in (True, "True", "true", 1):
            flags.append('<span class="flag flag-blue">HTTP</span>')
        if item.get("is_secure") in (True, "True", "true", 1):
            flags.append('<span class="flag flag-green">Secure</span>')
        flags_html = "".join(flags)
        rows.append(
            "<tr>"
            + cell(host, short=True)
            + f"<td>{text_cell(name, strong=True)}{flags_html}</td>"
            + f"<td>{copy_cell(value)}</td></tr>"
        )
    return table_html(
        "cookies", ["Host Domain", "Cookie Name", "Value"],
        rows, '  <colgroup><col class="w-domain"><col class="w-name"><col class="w-val"></colgroup>\n',
    )


def build_downloads(browser_label, items):
    if not items:
        return '<div class="pane-card empty-pane"><div class="empty-art">⬇️</div><p class="empty-title">No downloads yet</p><p class="empty-sub">Download records will appear after extraction.</p></div>'
    rows = []
    for item in items:
        url = field(item, ["url"], "#")
        path = field(item, ["target_path"], "")
        fname = os.path.basename(str(path)) if path else "—"
        size = format_size(field(item, ["total_bytes"], None))
        stime = field(item, ["start_time"], "0")
        rows.append(
            "<tr>"
            + f'<td>{link_cell(url)}<span class="dl-path">{esc(fname)}</span></td>'
            + time_cell(stime)
            + cell(size, strong=True)
            + cell(field(item, ["mime_type"], "—"), short=True)
            + "</tr>"
        )
    return table_html(
        "downloads", ["Source", "Started", "Size", "Type"],
        rows, '  <colgroup><col class="w-url"><col class="w-time"><col class="w-size"><col class="w-type"></colgroup>\n',
    )


def build_extensions(browser_label, items):
    if not items:
        return '<div class="pane-card empty-pane"><div class="empty-art">🧩</div><p class="empty-title">No extensions</p><p class="empty-sub">Installed extensions will show up here.</p></div>'
    rows = []
    for item in items:
        name = field(item, ["name"], "Untitled extension")
        eid = field(item, ["id"], "—")
        version = field(item, ["version"], "—")
        desc = field(item, ["description"], "")
        enabled = item.get("enabled") not in (False, "False", "false", 0, "0", "")
        badge = '<span class="flag flag-green">Enabled</span>' if enabled else '<span class="flag flag-red">Disabled</span>'
        rows.append(
            "<tr>"
            + f"<td>{text_cell(name, strong=True)}{badge}</td>"
            + f"<td><code class=\"ext-id\">{esc(eid)}</code></td>"
            + cell(version)
            + cell(desc if desc else "—", short=True)
            + "</tr>"
        )
    return table_html(
        "extensions", ["Name", "Extension ID", "Version", "Description"],
        rows, '  <colgroup><col class="w-name"><col class="w-extid"><col class="w-ver"><col class="w-desc"></colgroup>\n',
    )


def table_html(table_id, headers, rows, colgroup=""):
    head = "".join(f"<th>{h}</th>" for h in headers)
    body = "".join(rows)
    return (
        '<div class="table-card">\n'
        f'  <table class="data-table" id="{table_id}">\n'
        f"{colgroup}"
        f"    <thead><tr>{head}</tr></thead>\n"
        f"    <tbody>{body}</tbody>\n"
        "  </table>\n"
        '</div><div class="no-results">No entries match your search.</div>'
    )


def pane_html(pane_id, title, subtitle, content):
    return (
        f'<div class="pane" data-pane="{pane_id}">\n'
        f'  <div class="pane-head">\n'
        f'    <h2>{title}</h2>\n'
        f'    <span class="pane-sub">{subtitle}</span>\n'
        "  </div>\n"
        f"  {content}\n"
        "</div>"
    )


def build_panel(browser_id, label, icon, all_data):
    source_key = {"pass": "password", "hist": "history", "book": "bookmark", "cook": "cookie", "down": "download", "ext": "extension"}
    counts = {}
    panes = {}
    for key, builder, title, sub in [
        ("pass", build_passwords, "Saved Passwords", "Credentials recovered from this profile"),
        ("hist", build_history, "Browsing History", "Pages you have visited"),
        ("book", build_bookmarks, "Bookmarks", "Your saved sites"),
        ("cook", build_cookies, "Cookies", "Session cookies recovered"),
        ("down", build_downloads, "Downloads", "Files you have downloaded"),
        ("ext", build_extensions, "Extensions", "Installed browser extensions"),
    ]:
        items = filter_by_browser(all_data[source_key[key]], browser_id)
        counts[key] = len(items)
        panes[key] = pane_html(key, title, sub, builder(browser_id, items))

    tabs = ""
    for key, tab_label, tab_icon in [
        ("pass", "Passwords", "key"),
        ("hist", "History", "clock"),
        ("book", "Bookmarks", "star"),
        ("cook", "Cookies", "cookie"),
        ("down", "Downloads", "download"),
        ("ext", "Extensions", "puzzle"),
    ]:
        active = " active" if key == "pass" else ""
        tabs += (
            f'<button class="tab{active}" data-browser="{browser_id}" data-pane="{key}">'
            f'<span class="ico ico-{tab_icon}"></span>{tab_label}'
            f'<span class="pill">{counts[key]}</span></button>'
        )

    return (
        f'<section class="browser-panel" id="panel-{browser_id}" data-browser="{browser_id}">\n'
        f'  <div class="tabs">{tabs}</div>\n'
        + "".join(panes.values())
        + "</section>"
    )


def hero_stats(all_data):
    def count(key):
        return sum(len(filter_by_browser(all_data[key], b)) for b in ("safari", "brave"))
    return (
        f'<div class="stat" data-count="{count("password")}"><span class="stat-ico ico ico-key"></span><div><b class="stat-val">0</b><span class="stat-lbl">Passwords</span></div></div>'
        f'<div class="stat" data-count="{count("history")}"><span class="stat-ico ico ico-clock"></span><div><b class="stat-val">0</b><span class="stat-lbl">History entries</span></div></div>'
        f'<div class="stat" data-count="{count("bookmark")}"><span class="stat-ico ico ico-star"></span><div><b class="stat-val">0</b><span class="stat-lbl">Bookmarks</span></div></div>'
        f'<div class="stat" data-count="{count("cookie")}"><span class="stat-ico ico ico-cookie"></span><div><b class="stat-val">0</b><span class="stat-lbl">Cookies</span></div></div>'
    )


TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="color-scheme" content="dark">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🛰️</text></svg>">
<title>Mochi Vault — Browser Data Dashboard</title>
__STYLES__
</head>
<body>
<div class="orb orb-a"></div><div class="orb orb-b"></div><div class="orb orb-c"></div>
<div class="grid-overlay"></div>

<main class="shell">
  <header class="hero">
    <span class="hero-badge"><span class="beacon"></span>Recovery engine online</span>
    <h1 class="hero-title">Mochi <em>Vault</em></h1>
    <p class="hero-sub">Your browser universe — decoded, unified &amp; beautifully organized.</p>
    <div class="stats">__STATS__</div>
    <div class="clockline">Local time <b id="clock">00:00:00</b><span class="dot">·</span><span id="refreshed"></span></div>
    <div class="search-shell">
      <span class="search-ico">⌕</span>
      <input id="search" class="search-box" type="search" placeholder="Search the current view…" autocomplete="off">
      <span id="search-count" class="search-count"></span>
    </div>
  </header>

  <nav class="browser-nav">
    <div class="seg"><div class="seg-glider"></div>
      <button class="seg-btn active" data-browser="safari"><span class="brand-ico brand-safari">🧭</span>Safari</button>
      <button class="seg-btn" data-browser="brave"><span class="brand-ico brand-brave">🦁</span>Brave</button>
    </div>
  </nav>

  <div id="panels">__PANELS__</div>

  <footer class="foot">Mochi Vault — generated locally · your data never leaves this machine</footer>
</main>

<div class="toast" id="toast"><span class="toast-ico">✓</span><span id="toast-msg">Copied</span></div>

__SCRIPTS__
</body>
</html>
"""


STYLES = """
<style>
  :root {
    --bg: #07080f;
    --panel: rgba(18, 20, 34, 0.62);
    --panel-2: rgba(255, 255, 255, 0.04);
    --line: rgba(255, 255, 255, 0.08);
    --line-2: rgba(255, 255, 255, 0.13);
    --text: #eef0ff;
    --muted: #9aa2c0;
    --faint: #636a88;
    --acc1: #6366f1;
    --acc2: #a855f7;
    --acc3: #ec4899;
    --grad: linear-gradient(120deg, #818cf8, #c084fc 45%, #f472b6);
    --green: #34d399;
    --red: #fb7185;
    --amber: #fbbf24;
    --radius: 20px;
    --shadow: 0 24px 60px -24px rgba(0, 0, 0, 0.65);
  }

  * { box-sizing: border-box; }
  html { scroll-behavior: smooth; }
  body {
    margin: 0;
    min-height: 100vh;
    background: var(--bg);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    overflow-x: hidden;
    -webkit-font-smoothing: antialiased;
  }

  .orb { position: fixed; z-index: -2; border-radius: 50%; filter: blur(130px); opacity: 0.42; animation: drift 26s ease-in-out infinite alternate; }
  .orb-a { width: 560px; height: 560px; left: -160px; top: -160px; background: #4338ca; }
  .orb-b { width: 480px; height: 480px; right: -140px; top: 6%; background: #be185d; animation-delay: -8s; }
  .orb-c { width: 620px; height: 620px; left: 22%; bottom: -240px; background: #0e7490; animation-delay: -16s; }
  @keyframes drift {
    0% { transform: translate(0, 0) scale(1); }
    50% { transform: translate(60px, -50px) scale(1.08); }
    100% { transform: translate(-50px, 40px) scale(0.94); }
  }

  .grid-overlay {
    position: fixed; inset: 0; z-index: -1; pointer-events: none; opacity: 0.5;
    background-image:
      linear-gradient(rgba(255,255,255,0.022) 1px, transparent 1px),
      linear-gradient(90deg, rgba(255,255,255,0.022) 1px, transparent 1px);
    background-size: 56px 56px;
    mask-image: radial-gradient(ellipse at 50% 0%, black 30%, transparent 75%);
  }

  .shell { max-width: 1180px; margin: 0 auto; padding: 0 24px 60px; }

  .hero { text-align: center; padding: 64px 0 30px; position: relative; }
  .hero-badge {
    display: inline-flex; align-items: center; gap: 9px;
    font-size: 12px; letter-spacing: 0.09em; text-transform: uppercase; font-weight: 600;
    color: var(--muted); background: var(--panel-2); border: 1px solid var(--line);
    padding: 8px 16px; border-radius: 999px; margin-bottom: 22px;
  }
  .beacon { width: 7px; height: 7px; border-radius: 50%; background: var(--green); box-shadow: 0 0 0 0 rgba(52,211,153,0.55); animation: pulse 2.2s infinite; }
  @keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(52,211,153,0.5); } 70% { box-shadow: 0 0 0 9px rgba(52,211,153,0); } 100% { box-shadow: 0 0 0 0 rgba(52,211,153,0); } }

  .hero-title {
    font-size: clamp(44px, 8vw, 76px); font-weight: 800; letter-spacing: -0.03em; margin: 0 0 10px;
    background: linear-gradient(180deg, #ffffff 20%, #aab3ff 90%);
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .hero-title em {
    font-style: normal;
    background: var(--grad); -webkit-background-clip: text; background-clip: text; color: transparent;
    filter: drop-shadow(0 4px 26px rgba(168,85,247,0.35));
  }
  .hero-sub { color: var(--muted); font-size: 17px; margin: 0 0 30px; font-weight: 400; }

  .stats { display: flex; justify-content: center; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; }
  .stat {
    display: flex; align-items: center; gap: 12px; min-width: 180px;
    background: var(--panel); border: 1px solid var(--line); border-radius: 16px;
    padding: 14px 18px; backdrop-filter: blur(18px); -webkit-backdrop-filter: blur(18px);
    transition: transform 0.25s ease, border-color 0.25s ease, box-shadow 0.25s ease;
  }
  .stat:hover { transform: translateY(-3px); border-color: var(--line-2); box-shadow: 0 18px 40px -22px rgba(129,140,248,0.55); }
  .stat b { display: block; font-size: 24px; font-weight: 800; letter-spacing: -0.02em; }
  .stat-lbl { font-size: 12px; color: var(--faint); text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; }

  .ico { display: inline-grid; place-items: center; width: 38px; height: 38px; border-radius: 12px; flex: none; }
  .stat-ico { font-size: 18px; }

  .ico-key  { background: rgba(129,140,248,0.16); color: #a5b4fc; box-shadow: inset 0 0 0 1px rgba(129,140,248,0.35); }
  .ico-clock{ background: rgba(52,211,153,0.14); color: #6ee7b7; box-shadow: inset 0 0 0 1px rgba(52,211,153,0.3); }
  .ico-star { background: rgba(251,191,36,0.14); color: #fcd34d; box-shadow: inset 0 0 0 1px rgba(251,191,36,0.3); }
  .ico-cookie{background: rgba(244,114,182,0.15); color: #f9a8d4; box-shadow: inset 0 0 0 1px rgba(244,114,182,0.3); }
  .ico-puzzle{background: rgba(56,189,248,0.15); color: #7dd3fc; box-shadow: inset 0 0 0 1px rgba(56,189,248,0.3); }
  .ico-download{background: rgba(52,211,153,0.14); color: #6ee7b7; box-shadow: inset 0 0 0 1px rgba(52,211,153,0.3); }

  .ico:before, .ico:after { content: ""; box-shadow: inherit; }
  .ico-key { position: relative; }
  .ico-key:before { width: 14px; height: 14px; border: 2px solid currentColor; border-radius: 50px; transform: translateX(-4px); }
  .ico-key:after { width: 4px; height: 4px; border-radius: 50%; background: currentColor; transform: translate(7px, -9px); box-shadow: 2px -2px 0 -0px currentColor; }
  .ico-clock { position: relative; }
  .ico-clock:before { width: 16px; height: 16px; border: 2px solid currentColor; border-radius: 50%; }
  .ico-clock:after { width: 6px; height: 2px; background: currentColor; border-radius: 2px; transform: translate(-2px, 2px); }
  .ico-star { position: relative; }
  .ico-star:before { content: "★"; font-size: 17px; }
  .ico-cookie { position: relative; }
  .ico-cookie:before { content: "●"; font-size: 13px; text-shadow: -4px 0 0 currentColor, 3px 2px 0 currentColor, -1px -5px 0 currentColor; }
  .ico-download { position: relative; }
  .ico-download:before { width: 2px; height: 10px; background: currentColor; transform: translate(0, 1px); }
  .ico-download:after { width: 8px; height: 8px; border-left: 2px solid currentColor; border-bottom: 2px solid currentColor; transform: translate(3px, 4px) rotate(-45deg); }
  .ico-puzzle { position: relative; }
  .ico-puzzle:before { content: "🧩"; font-size: 16px; }

  .clockline { color: var(--faint); font-size: 13px; margin-bottom: 26px; }
  .clockline b { color: var(--muted); font-weight: 600; font-variant-numeric: tabular-nums; }
  .clockline .dot { margin: 0 8px; }

  .search-shell { position: sticky; top: 18px; z-index: 60; max-width: 620px; margin: 0 auto; }
  .search-box {
    width: 100%; padding: 17px 52px;
    background: var(--panel); border: 1px solid var(--line-2); border-radius: 999px;
    color: var(--text); font-size: 16px; outline: none;
    backdrop-filter: blur(22px); -webkit-backdrop-filter: blur(22px); box-shadow: var(--shadow);
    transition: border-color 0.25s ease, box-shadow 0.25s ease;
  }
  .search-box::placeholder { color: var(--faint); }
  .search-box:focus { border-color: rgba(139,92,246,0.75); box-shadow: 0 18px 50px -18px rgba(139,92,246,0.7); }
  .search-ico { position: absolute; left: 22px; top: 50%; transform: translateY(-52%); font-size: 22px; color: var(--faint); pointer-events: none; }
  .search-count { position: absolute; right: 18px; top: 50%; transform: translateY(-50%); font-size: 12px; font-weight: 700; color: var(--acc2); background: rgba(168,85,247,0.12); border: 1px solid rgba(168,85,247,0.3); padding: 4px 12px; border-radius: 999px; opacity: 0; transition: opacity 0.25s; }
  .search-count.show { opacity: 1; }

  .browser-nav { display: flex; justify-content: center; margin: 30px 0 6px; }
  .seg { position: relative; display: flex; background: var(--panel); border: 1px solid var(--line); border-radius: 999px; padding: 6px; backdrop-filter: blur(18px); }
  .seg-glider { position: absolute; top: 6px; left: 6px; height: calc(100% - 12px); width: calc(50% - 6px); border-radius: 999px; background: var(--grad); box-shadow: 0 8px 24px -8px rgba(236,72,153,0.6); transition: transform 0.32s cubic-bezier(0.68, -0.2, 0.27, 1.6); z-index: 0; }
  .seg-btn { position: relative; z-index: 1; display: flex; align-items: center; gap: 10px; background: transparent; border: 0; color: var(--muted); font-size: 16px; font-weight: 600; padding: 14px 34px; border-radius: 999px; cursor: pointer; transition: color 0.25s; }
  .seg-btn.active { color: #fff; }
  .brand-ico { font-size: 18px; }

  .tabs { display: flex; flex-wrap: wrap; justify-content: center; gap: 8px; margin: 26px 0 20px; }
  .tab {
    display: flex; align-items: center; gap: 9px;
    background: var(--panel-2); border: 1px solid var(--line); color: var(--muted);
    padding: 10px 18px; border-radius: 999px; font-size: 14px; font-weight: 600; cursor: pointer;
    transition: all 0.22s ease; font-family: inherit;
  }
  .tab:hover { color: var(--text); border-color: var(--line-2); transform: translateY(-2px); }
  .tab.active { color: #fff; background: linear-gradient(120deg, rgba(129,140,248,0.22), rgba(236,72,153,0.2)); border-color: rgba(168,85,247,0.55); box-shadow: 0 10px 26px -14px rgba(168,85,247,0.7); }
  .tab .ico { width: 18px; height: 18px; border-radius: 6px; }
  .tab .ico.key  { box-shadow: inset 0 0 0 1px rgba(165,180,252,0.4); }
  .pill {
    font-size: 11px; font-weight: 700; background: rgba(255,255,255,0.1);
    border: 1px solid var(--line-2); border-radius: 999px; padding: 2px 9px; min-width: 26px; text-align: center;
  }
  .tab:not(.active) .pill { color: var(--muted); }

  .browser-panel { display: none; animation: fadeUp 0.5s cubic-bezier(0.22, 1, 0.36, 1); }
  .browser-panel.active { display: block; }
  @keyframes fadeUp { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: none; } }

  .pane { display: none; animation: fadeUp 0.4s cubic-bezier(0.22, 1, 0.36, 1); }
  .pane.active { display: block; }

  .pane-head { display: flex; align-items: baseline; justify-content: space-between; gap: 16px; margin: 4px 4px 18px; flex-wrap: wrap; }
  .pane-head h2 { margin: 0; font-size: 26px; font-weight: 800; letter-spacing: -0.02em; }
  .pane-head h2::before { content: "🛰"; font-size: 18px; margin-right: 10px; opacity: 0.85; }
  .pane-sub { color: var(--faint); font-size: 13px; }

  .table-card {
    position: relative;
    background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius);
    backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); box-shadow: var(--shadow);
    overflow: hidden;
  }
  .table-card::before {
    content: ""; position: absolute; inset: 0 0 auto 0; height: 1px; z-index: 1;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.18), transparent);
  }

  .data-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
  .data-table thead th {
    text-align: left; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em;
    color: var(--faint); padding: 15px 18px; background: rgba(10, 12, 22, 0.5);
    border-bottom: 1px solid var(--line); white-space: nowrap;
  }
  .data-table td {
    font-size: 14px; color: var(--muted); padding: 13px 18px; border-bottom: 1px solid var(--line);
    vertical-align: middle; word-break: break-word;
  }
  .data-table tbody tr { transition: background 0.18s ease, transform 0.2s ease; animation: rowIn 0.45s cubic-bezier(0.22,1,0.36,1) both; animation-delay: calc(var(--i, 0) * 40ms); }
  @keyframes rowIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
  .data-table tbody tr:hover { background: rgba(129,140,248,0.07); }
  .data-table tbody tr:last-child td { border-bottom: 0; }
  .data-table td strong { color: var(--text); font-weight: 600; }
  .data-table td code {
    display: inline-block; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    background: rgba(10, 12, 22, 0.7); border: 1px solid var(--line); border-radius: 8px;
    color: #f9a8d4; padding: 4px 10px; font-size: 12.5px; vertical-align: middle;
  }

  .url-link { color: #7cc7ff; text-decoration: none; font-weight: 500; transition: color 0.18s; }
  .url-link:hover { color: #b3e0ff; text-decoration: underline; }

  .cell-short { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  .cell-title strong { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .visits {
    display: inline-block; margin-top: 4px; font-size: 11px; font-weight: 700;
    color: #7dd3fc; background: rgba(56,189,248,0.1); border: 1px solid rgba(56,189,248,0.28);
    padding: 1px 8px; border-radius: 999px;
  }

  .hist-time { color: var(--muted); font-size: 12.5px; font-variant-numeric: tabular-nums; white-space: nowrap; }

  .copy-wrap { display: flex; align-items: center; gap: 8px; max-width: 100%; }
  .copy-wrap.slim { }
  .copy-btn, .delete-btn {
    font-family: inherit; font-size: 11px; font-weight: 700; border-radius: 8px; padding: 6px 12px;
    cursor: pointer; transition: all 0.18s ease; border: 1px solid; letter-spacing: 0.02em;
  }
  .copy-btn {
    flex: none; color: #c7d2fe; background: rgba(129,140,248,0.1); border-color: rgba(129,140,248,0.35);
  }
  .copy-btn:hover { background: rgba(129,140,248,0.22); color: #fff; transform: translateY(-1px); }
  .copy-btn.copied { background: rgba(52,211,153,0.18) !important; border-color: rgba(52,211,153,0.5) !important; color: #6ee7b7 !important; }
  .delete-btn { color: #fda4af; background: rgba(244,63,94,0.1); border-color: rgba(244,63,94,0.35); }
  .delete-btn:hover { background: rgba(244,63,94,0.25); color: #fff; transform: translateY(-1px); box-shadow: 0 8px 20px -10px rgba(244,63,94,0.6); }

  .cell-action { width: 96px; text-align: right; }
  .flag { display: inline-block; font-size: 9px; font-weight: 800; letter-spacing: 0.08em; text-transform: uppercase; padding: 2px 7px; border-radius: 999px; margin-left: 7px; vertical-align: 2px; }
  .flag-green { color: #6ee7b7; background: rgba(52,211,153,0.12); border: 1px solid rgba(52,211,153,0.32); }
  .flag-blue  { color: #7dd3fc; background: rgba(56,189,248,0.12); border: 1px solid rgba(56,189,248,0.32); }
  .flag-red   { color: #fda4af; background: rgba(244,63,94,0.12); border: 1px solid rgba(244,63,94,0.32); }

  .folder-tag { display: inline-block; margin-left: 8px; font-size: 11px; color: #c4b5fd; background: rgba(167,139,250,0.1); border: 1px solid rgba(167,139,250,0.3); padding: 1px 9px; border-radius: 999px; }
  .ext-id { font-family: ui-monospace, "SF Mono", Menlo, monospace; font-size: 11px !important; }
  .dl-path { display: block; color: var(--faint); font-size: 12px; margin-top: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  .no-results { display: none; text-align: center; color: var(--faint); font-size: 14px; padding: 34px 16px; font-style: italic; }

  .empty-pane {
    text-align: center; padding: 60px 24px;
    background: var(--panel); border: 1px dashed var(--line-2); border-radius: var(--radius);
    backdrop-filter: blur(20px); box-shadow: var(--shadow);
  }
  .empty-art { font-size: 46px; margin-bottom: 14px; animation: bob 3s ease-in-out infinite; display: inline-block; }
  @keyframes bob { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-9px); } }
  .empty-title { margin: 0 0 6px; font-size: 19px; font-weight: 700; color: var(--text); }
  .empty-sub { margin: 0; color: var(--faint); font-size: 14px; }

  .foot { text-align: center; color: var(--faint); font-size: 12.5px; margin-top: 44px; letter-spacing: 0.02em; }

  .toast {
    position: fixed; left: 50%; bottom: 30px; transform: translate(-50%, 80px);
    display: flex; align-items: center; gap: 10px;
    background: rgba(16, 18, 32, 0.9); border: 1px solid var(--line-2); border-radius: 999px;
    padding: 12px 20px; font-size: 14px; font-weight: 600; color: var(--text);
    box-shadow: 0 20px 50px -16px rgba(0,0,0,0.8); backdrop-filter: blur(18px);
    opacity: 0; pointer-events: none; transition: all 0.32s cubic-bezier(0.68, -0.2, 0.27, 1.4); z-index: 100;
  }
  .toast.show { transform: translate(-50%, 0); opacity: 1; }
  .toast-ico {
    display: grid; place-items: center; width: 22px; height: 22px; border-radius: 50%;
    background: rgba(52,211,153,0.18); color: #6ee7b7; font-size: 13px; font-weight: 800;
  }

  ::-webkit-scrollbar { width: 11px; height: 11px; }
  ::-webkit-scrollbar-track { background: var(--bg); }
  ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 8px; border: 3px solid var(--bg); }
  ::-webkit-scrollbar-thumb:hover { background: rgba(168,85,247,0.4); }

  ::selection { background: rgba(168,85,247,0.4); color: #fff; }

  @media (max-width: 720px) {
    .shell { padding: 0 14px 40px; }
    .hero { padding-top: 42px; }
    .stat { min-width: 130px; padding: 10px 12px; }
    .seg-btn { padding: 12px 20px; font-size: 14px; }
    .row-repair { }
    .data-table thead { display: none; }
    .data-table, .data-table tbody, .data-table tr, .data-table td { display: block; width: 100%; }
    .data-table tr { border-bottom: 1px solid var(--line); padding: 12px 4px; }
    .data-table td { border: 0; padding: 5px 16px; }
    .data-table td:first-child { padding-top: 10px; }
    .cell-action { text-align: left; }
  }

  @media (min-width: 721px) {
    .w-time { width: 15%; } .w-title { width: 30%; } .w-url { width: 40%; } .w-act { width: 96px; }
    .w-url { width: 42%; } .w-user { width: 26%; } .w-pwd { width: 32%; }
    .w-domain { width: 22%; } .w-name { width: 24%; } .w-val { width: 54%; }
    .w-size { width: 12%; } .w-type { width: 22%; }
    .w-extid { width: 30%; } .w-ver { width: 9%; } .w-desc { width: 35%; }
  }
</style>
"""


SCRIPTS = """
<script>
  const panels = [...document.querySelectorAll('.browser-panel')];
  const segBtns = [...document.querySelectorAll('.seg-btn')];
  const segGlider = document.querySelector('.seg-glider');

  function moveGlider(btn) {
    if (!btn || !segGlider) return;
    segGlider.style.transform = `translateX(${btn.offsetLeft - 6}px)`;
    segGlider.style.width = `${btn.offsetWidth}px`;
  }

  function switchBrowser(b) {
    segBtns.forEach(x => x.classList.toggle('active', x.dataset.browser === b));
    moveGlider(segBtns.find(x => x.dataset.browser === b));
    panels.forEach(p => {
      const on = p.id === 'panel-' + b;
      p.classList.toggle('active', on);
      if (on) {
        p.querySelectorAll('.tab').forEach((t, i) => {
          t.classList.toggle('active', i === 0);
        });
        p.querySelectorAll('.pane').forEach((z, i) => {
          z.classList.toggle('active', i === 0);
          z.style.setProperty('--i', i);
        });
      }
    });
    setRowDelays();
    filterDashboard();
  }

  function switchPane(tab) {
    const panel = tab.closest('.browser-panel');
    panel.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t === tab));
    panel.querySelectorAll('.pane').forEach(pz => pz.classList.toggle('active', pz.dataset.pane === tab.dataset.pane));
    setRowDelays();
    document.getElementById('search').value = '';
    document.getElementById('search-count').classList.remove('show');
    document.querySelectorAll('.no-results').forEach(n => n.style.display = 'none');
    filterDashboard();
  }

  function setRowDelays() {
    const activePane = document.querySelector('.browser-panel.active .pane.active');
    if (!activePane) return;
    activePane.querySelectorAll('tbody tr').forEach((r, i) => r.style.setProperty('--i', i));
  }

  function filterDashboard() {
    const q = document.getElementById('search').value.trim().toLowerCase();
    const panel = document.querySelector('.browser-panel.active');
    if (!panel) return;
    const pane = panel.querySelector('.pane.active');
    if (!pane) return;

    let visibleRows = 0;
    pane.querySelectorAll('tbody tr').forEach(row => {
      const match = !q || row.textContent.toLowerCase().includes(q);
      row.style.display = match ? '' : 'none';
      if (match) visibleRows++;
    });

    const table = pane.querySelector('.data-table');
    const empty = pane.querySelector('.no-results');
    if (table) table.style.display = (visibleRows === 0) ? 'none' : '';
    if (empty) empty.style.display = (visibleRows === 0) ? 'block' : 'none';

    const count = document.getElementById('search-count');
    if (q) {
      count.textContent = visibleRows + (visibleRows === 1 ? ' result' : ' results');
      count.classList.add('show');
    } else {
      count.classList.remove('show');
    }
  }

  const toast = document.getElementById('toast');
  const toastMsg = document.getElementById('toast-msg');
  let toastTimer;
  function showToast(msg) {
    toastMsg.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 1800);
  }

  document.addEventListener('click', e => {
    const copyBtn = e.target.closest('.copy-btn');
    if (copyBtn) {
      const val = copyBtn.dataset.copy || '';
      navigator.clipboard.writeText(val).then(() => {
        copyBtn.textContent = 'Copied';
        copyBtn.classList.add('copied');
        setTimeout(() => { copyBtn.textContent = 'Copy'; copyBtn.classList.remove('copied'); }, 1400);
        showToast('Copied to clipboard');
      }).catch(() => showToast('Copy failed'));
      return;
    }

    const delBtn = e.target.closest('.delete-btn');
    if (delBtn) {
      const title = delBtn.dataset.title || '';
      if (!title) return;
      if (!confirm('Delete all local history matching: "' + title + '"? Copy the command below to permanently purge it from your files.')) return;
      navigator.clipboard.writeText('python3 "' + PROJECT_DIR + '/dashboard.py" clear "' + title + '"').then(
        () => showToast('Purge command copied to clipboard')
      );
      const row = delBtn.closest('tr');
      if (row) {
        row.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        row.style.opacity = '0';
        row.style.transform = 'translateX(30px)';
        setTimeout(() => { row.remove(); filterDashboard(); showToast('Entry removed from view'); }, 300);
      }
      return;
    }

    if (e.target.closest('.seg-btn')) {
      switchBrowser(e.target.closest('.seg-btn').dataset.browser);
      return;
    }
    const tab = e.target.closest('.tab');
    if (tab) switchPane(tab);
  });

  function formatHist() {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    document.querySelectorAll('.hist-time').forEach(el => {
      let raw = el.dataset.raw;
      if (!raw || raw === 'N/A' || raw === '0' || raw === '—') { el.textContent = '—'; return; }
      let d = new Date(raw);
      if (isNaN(d.getTime()) && !isNaN(Number(raw))) {
        let n = Number(raw);
        if (String(raw).length >= 16) d = new Date((n / 1000000 - 11644473600) * 1000);
        else d = new Date(n < 10000000000 ? n * 1000 : n);
      }
      if (!d || isNaN(d.getTime())) return;
      let h = d.getHours(), ap = h >= 12 ? 'PM' : 'AM';
      h = h % 12 || 12;
      const rel = (elapsed) => {
        const s = Math.floor(elapsed / 1000);
        if (s < 60) return 'just now';
        if (s < 3600) return Math.floor(s / 60) + 'm ago';
        if (s < 86400) return Math.floor(s / 3600) + 'h ago';
        if (s < 604800) return Math.floor(s / 86400) + 'd ago';
        return Math.floor(s / 604800) + 'w ago';
      };
      const label = `${days[d.getDay()]} ${months[d.getMonth()]} ${d.getDate()} · ${String(h).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')} ${ap}`;
      const age = Date.now() - d.getTime();
      el.textContent = (age > 0 && age < 1.6e8) ? `${label} · ${rel(age)}` : label;
      el.title = el.dataset.raw;
    });
  }

  function tickClock() {
    const c = document.getElementById('clock');
    if (!c) return;
    c.textContent = new Date().toLocaleTimeString('en-US', { hour12: false });
  }

  function animateStats() {
    document.querySelectorAll('.stat').forEach(stat => {
      const target = parseInt(stat.dataset.count || '0', 10);
      const el = stat.querySelector('.stat-val');
      const t0 = performance.now();
      const dur = 900;
      function step(now) {
        const p = Math.min((now - t0) / dur, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(target * eased).toLocaleString();
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    });
  }

  document.getElementById('search').addEventListener('input', filterDashboard);
  window.addEventListener('resize', () => moveGlider(document.querySelector('.seg-btn.active')));

  document.addEventListener('DOMContentLoaded', () => {
    switchBrowser('safari');
    formatHist();
    tickClock();
    setInterval(tickClock, 1000);
    animateStats();
    const ref = document.getElementById('refreshed');
    if (ref) ref.textContent = 'Refreshed ' + new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  });
</script>
"""


def build_dashboard(open_after=False):
    all_data = {key: load_json(os.path.join(RESULTS_DIR, fname)) for key, fname in DATA_SOURCES}

    panels_html = ""
    for browser_id, label, icon in [("safari", "Safari", "🧭"), ("brave", "Brave", "🦁")]:
        panels_html += build_panel(browser_id, label, icon, all_data)

    html_out = (
        TEMPLATE.replace("__STYLES__", STYLES)
        .replace("__STATS__", hero_stats(all_data))
        .replace("__PANELS__", panels_html)
        .replace(
            "__SCRIPTS__",
            SCRIPTS.replace("PROJECT_DIR", json.dumps(PROJECT_DIR)),
        )
    )

    os.makedirs(RESULTS_DIR, exist_ok=True)
    out_path = os.path.join(RESULTS_DIR, "dashboard.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html_out)

    print(f"[+] Dashboard compiled → {out_path}")
    print(f"[+] Safari: {len(filter_by_browser(all_data['history'], 'safari'))} · Brave: {len(filter_by_browser(all_data['history'], 'brave'))} history entries")
    if open_after:
        webbrowser.open("file://" + out_path)
        print("[+] Opened in your browser.")


def clear_history(target_input):
    history_path = os.path.join(RESULTS_DIR, "history.json")
    if not os.path.exists(history_path):
        print("[-] history.json not found. Run the extractor first.")
        sys.exit(1)

    with open(history_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    target = target_input.strip().lower()
    kept, removed = [], 0
    for entry in data:
        title = str(entry.get("title") or entry.get("Title") or "").strip().lower()
        if target and target in title:
            removed += 1
        else:
            kept.append(entry)

    if removed == 0:
        print(f"[*] No history matched '{target_input}' — nothing to remove.")
        return 0

    with open(history_path, "w", encoding="utf-8") as f:
        json.dump(kept, f, indent=2, ensure_ascii=False)
    print(f"[+] Removed {removed} record(s) matching '{target_input}' from history.json")
    build_dashboard()
    return removed


def show_categories(category=None):
    order = ["password", "history", "bookmark", "cookie", "download", "extension", "localstorage", "sessionstorage"]
    if category:
        order = [category]
    for key in order:
        path = os.path.join(RESULTS_DIR, f"{key}.json")
        if not os.path.exists(path):
            print(f"[*] No {key}.json present.")
            continue
        data = load_json(path)
        print("=" * 42)
        print(f"   {key.upper()}  ({len(data)} entries)")
        print("=" * 42)
        if not data:
            print("   (empty)")
            continue
        for item in data:
            if key in ("password",):
                print(f"  Site     : {field(item, ['url', 'origin_url'])}")
                print(f"  Username : {field(item, ['username', 'username_value'])}")
                print(f"  Password : {field(item, ['password', 'password_value'])}")
            elif key == "history":
                print(f"  Time  : {field(item, ['last_visit', 'visit_time', 'time'])}")
                print(f"  Title : {field(item, ['title'])}")
                print(f"  URL   : {field(item, ['url'])}")
            elif key == "bookmark":
                print(f"  Name : {field(item, ['name', 'title'])}")
                print(f"  URL  : {field(item, ['url'])}")
            elif key == "cookie":
                print(f"  {field(item, ['host', 'domain'])}  →  {field(item, ['name'])}")
            elif key == "download":
                print(f"  {os.path.basename(field(item, ['target_path'], ''))}")
                print(f"  from {field(item, ['url'])}  ({format_size(field(item, ['total_bytes'], None))})")
            elif key == "extension":
                print(f"  {field(item, ['name'])}  v{field(item, ['version'])}  [{field(item, ['id'])}]")
            else:
                print(f"  {field(item, ['url'], '?')}  ·  {field(item, ['key'])} = {str(field(item, ['value']))[:60]}")
            print("-" * 32)
    print("\n[+] Tip: run `dashboard.py build` to render the visual dashboard.")


def merge_files(source_name, dest_name):
    source_path = os.path.join(PROJECT_DIR, source_name)
    dest_path = os.path.join(PROJECT_DIR, dest_name)
    if not os.path.exists(source_path):
        print(f"[-] Source file '{source_name}' not found.")
        return 1
    with open(source_path, "r", encoding="utf-8") as src:
        content = src.read()
    with open(dest_path, "a", encoding="utf-8") as dest:
        dest.write("\n\n# --- Merged: " + source_name + " ---\n")
        dest.write(content)
    print(f"[+] Appended {source_name} → {dest_name}")
    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="dashboard.py",
        description="Mochi Vault — one command to build, browse and clean your browser data.",
    )
    sub = parser.add_subparsers(dest="command")

    b = sub.add_parser("build", help="Compile the dashboard and open it")
    b.add_argument("--no-open", action="store_true", help="Build without opening the browser")

    p = sub.add_parser("clear", help='Delete history matching a keyword, e.g. dashboard.py clear "youtube"')
    p.add_argument("term", help="Keyword or page title to remove")

    s = sub.add_parser("show", help="Print recovered data in the terminal")
    s.add_argument("category", nargs="?", help="password | history | bookmark | cookie | download | extension | ...")

    m = sub.add_parser("merge", help="Append one file to another")
    m.add_argument("source")
    m.add_argument("dest")

    u = sub.add_parser("setup", help="Store the macOS login password in the Keychain once (enables auto-unlock)")
    u.add_argument("-p", "--password", help="Supply the password directly instead of prompting")

    f = sub.add_parser("forget", help="Remove the stored keychain password")

    args = parser.parse_args()

    if args.command == "build" or args.command is None:
        build_dashboard(open_after=not getattr(args, "no_open", False))
    elif args.command == "clear":
        clear_history(args.term)
    elif args.command == "show":
        show_categories(args.category)
    elif args.command == "merge":
        sys.exit(merge_files(args.source, args.dest))
    elif args.command == "setup":
        pw = getattr(args, "password", None) or os.environ.get("VAULT_PW")
        if not pw:
            import getpass
            pw = getpass.getpass("macOS login password (stored encrypted in the system Keychain): ")
        if not pw:
            print("[-] No password given.")
            sys.exit(1)
        if keychain_set(pw):
            print("[+] Saved to the system Keychain. Future runs decrypt automatically.")
        else:
            print("[-] Could not save to the Keychain.")
            sys.exit(1)
    elif args.command == "forget":
        keychain_forget()
        print("[+] Removed stored keychain password.")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()